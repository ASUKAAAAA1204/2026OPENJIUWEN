"""Portable local verification for A's B-R1 follow-up; no model or network calls."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reproduce", type=Path, help="New output directory outside this immutable packet")
    parser.add_argument("--tests", action="store_true", help="Run the 57 offline A S3 tests; requires --reproduce")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    seen = set()
    for entry in manifest["files"]:
        name = entry["path"]
        relative = PurePosixPath(name)
        path = (root / name).resolve()
        if (name in seen or relative.is_absolute() or "\\" in name or ":" in name
                or any(part in {"", ".", ".."} for part in name.split("/")) or not path.is_relative_to(root)):
            raise ValueError("Invalid manifest path")
        seen.add(name)
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"] or len(raw) != entry["bytes"]:
            raise ValueError(f"File integrity mismatch: {name}")
    summary = {"status": "passed", "files_verified": len(seen), "new_model_calls": 0}
    if args.tests and args.reproduce is None:
        parser.error("--tests requires --reproduce")
    if args.reproduce is not None:
        destination = args.reproduce.resolve()
        if destination.is_relative_to(root):
            raise ValueError("Reproduction output must be outside the original packet")
        destination.mkdir(parents=True, exist_ok=False)
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(root / "runtime/src"))
        from assurance_ledger.rail.evidence_capture import export_capture_packages
        from assurance_ledger.rail.evidence_io import read_json
        from assurance_ledger.ledger.packer import check_package_integrity
        import assurance_ledger.rail.evidence_capture as implementation
        if not Path(implementation.__file__).resolve().is_relative_to(root / "runtime/src"):
            raise ValueError("Wrong implementation loaded")
        stored = read_json(root / "data/evidence/report.json")
        for entry in stored["packages"]:
            package = read_json(root / "data/evidence" / entry["package_file"])
            if check_package_integrity(package)["status"] != "passed":
                raise ValueError("Stored evidence integrity failed")
            if package["minimality"]["status"] != "not_run" or package["bundle"]["adjudication"] is not None:
                raise ValueError("Unexpected formal verification assertion")
        regenerated = export_capture_packages(root / "data/capture", destination / "exports",
                                              b_rule_return=root / "data/b_return")
        if regenerated["status"] != "passed" or regenerated["packaged_claim_count"] != 100:
            raise ValueError("Candidate regeneration failed")
        regenerated_root = Path(regenerated["output_directory"])
        if [p["package_hash"] for p in regenerated["packages"]] != [p["package_hash"] for p in stored["packages"]]:
            raise ValueError("Evidence changed on relocation; timing belongs only in separate measurement files")
        costs = read_json(regenerated_root / "measurements/summary.json")
        summary.update({"packages_verified_and_reproduced": 100, "package_hashes_reproducible": True,
                        "rule_status": regenerated["rule_binding"]["status"],
                        "formal_M10": costs["M10"]["status"], "S3_model_calls": costs["model_calls"],
                        "new_output": str(regenerated_root)})
        if args.tests:
            env = os.environ.copy()
            env["PYTHONPATH"] = str(root / "runtime/src")
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            result = subprocess.run([sys.executable, "-m", "pytest", str(root / "runtime/fixtures/a_s3"),
                "-q", "-p", "no:cacheprovider", "--basetemp", str(destination / "pytest-temp"),
                "--junitxml", str(destination / "pytest.xml")],
                cwd=root / "runtime", env=env, capture_output=True, encoding="utf-8", timeout=60)
            (destination / "pytest-output.txt").write_text(result.stdout + "\n" + result.stderr, encoding="utf-8")
            if result.returncode != 0:
                raise RuntimeError("Offline S3 tests failed; inspect pytest-output.txt")
            summary["offline_S3_tests"] = "passed"
        (destination / "verification.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
